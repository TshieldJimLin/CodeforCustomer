package com.athemaster.bean;

public class RequestBean {

    private String cardType;
    private String cardNo;
    private String transType;
    private String dateTime;
    private String storeNo;
    private String posNo;

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getStoreNo() {
        return storeNo;
    }

    public void setStoreNo(String storeNo) {
        this.storeNo = storeNo;
    }

    public String getPosNo() {
        return posNo;
    }

    public void setPosNo(String posNo) {
        this.posNo = posNo;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,%s,%s,%s",
                this.cardType,
                this.cardNo,
                this.transType,
                this.dateTime,
                this.storeNo,
                this.posNo);
    }
}
