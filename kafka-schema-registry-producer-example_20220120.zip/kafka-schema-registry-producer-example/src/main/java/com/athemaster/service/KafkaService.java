package com.athemaster.service;

import com.athemaster.avro.SpentRecord;
import com.athemaster.bean.RequestBean;
import com.athemaster.utils.KafkaUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.Properties;

@Service
public class KafkaService {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaService.class);
    private Producer<String, SpentRecord> spentRecordProducer;
    private Producer<String, String> failDataProducer;

    @Value("${topic}")
    private String topic;

    @Value("${failTopic}")
    private String failTopic;

    @Autowired
    private KafkaUtils kafkaUtils;


    public void sendData(RequestBean requestBean) {
        if (spentRecordProducer == null) initProducer(topic);
        SpentRecord record = getSpentRecord(requestBean);
        LOGGER.info("Sending message: [{}] to topic: [{}]", record, topic);
        ProducerRecord<String, SpentRecord> producerRecord = new ProducerRecord<>(topic, String.valueOf(((int)Math.random()*3)), record);
        spentRecordProducer.send(producerRecord);
    }

    public void sendFailData(RequestBean requestBean) {
        if (failDataProducer == null) initProducer(failTopic);
        LOGGER.info("Sending message: [{}] to topic: [{}]", requestBean.toString(), failTopic);
        ProducerRecord<String, String> producerRecord = new ProducerRecord<>(failTopic, String.valueOf(((int)Math.random()*3)), requestBean.toString());
        failDataProducer.send(producerRecord);
    }

    public SpentRecord getSpentRecord(RequestBean requestBean) {
        SpentRecord record = new SpentRecord();
        record.setCardNo(requestBean.getCardNo());
        record.setCardType(requestBean.getCardType());
        record.setPosNo(requestBean.getPosNo());
        record.setStoreNo(requestBean.getStoreNo());
        record.setTransType(requestBean.getTransType());
        record.setDatetime(requestBean.getDateTime());
        return record;
    }

    private void initProducer(String topicName) {
        Properties properties = kafkaUtils.getProducerProperties(topicName);
        if (topicName.equals(this.topic)) spentRecordProducer = new KafkaProducer<>(properties);
        else failDataProducer = new KafkaProducer<>(properties);

    }


}
