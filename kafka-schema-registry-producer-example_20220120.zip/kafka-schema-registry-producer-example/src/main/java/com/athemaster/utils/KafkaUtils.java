package com.athemaster.utils;

import com.hortonworks.registries.schemaregistry.serdes.avro.kafka.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.util.Properties;

import static com.hortonworks.registries.schemaregistry.serdes.avro.AbstractAvroSnapshotSerializer.SERDES_PROTOCOL_VERSION;
import static com.hortonworks.registries.schemaregistry.serdes.avro.SerDesProtocolHandlerRegistry.METADATA_ID_VERSION_PROTOCOL;

@Component
public class KafkaUtils {

    @Value("${krb5Conf}")
    private String krb5Conf;

    @Value("${jaasConf}")
    private String jaasConf;

    @Value("${topic}")
    private String topic;

    @Value("${failTopic}")
    private String failTopic;

    @Value("${broker}")
    private String broker;

    @Value("${schemaRegistryUrl}")
    private String schemaRegistryUrl;


    public Properties getProducerProperties(String topicName) {
        doKerberosSetting();
        Properties properties = getKafkaProperties(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, topicName);
        properties.put(SERDES_PROTOCOL_VERSION, METADATA_ID_VERSION_PROTOCOL);
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, topicName.equals(this.topic) ? KafkaAvroSerializer.class : StringSerializer.class);
        properties.put("ignoreInvalidMessages", true);
        properties.put(ProducerConfig.ACKS_CONFIG, "all");
        return properties;
    }

    private void doKerberosSetting() {
        System.setProperty("java.security.krb5.conf", krb5Conf);
        System.setProperty("java.security.auth.login.config", jaasConf);
        System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");
    }

    private Properties getKafkaProperties(String bootstrapServersConfig, String topicName) {
        Properties properties = new Properties();
        properties.put("topic", topicName);
        properties.put(bootstrapServersConfig, broker);
        properties.put("schema.registry.url", schemaRegistryUrl);
        properties.put("security.protocol", "SASL_PLAINTEXT");
        properties.put("sasl.kerberos.service.name", "kafka");
        return properties;
    }
}
