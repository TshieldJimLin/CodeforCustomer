package com.athemaster.controller;

import com.athemaster.bean.RequestBean;
import com.athemaster.service.KafkaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/")
public class ApiController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApiController.class);

    @Autowired
    KafkaService kafkaService;

    @RequestMapping(value = "sendData", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public String sendData(@RequestBody RequestBean requestBean) {
        String status = "success";
        try {
            kafkaService.sendData(requestBean);
        } catch (Exception e){
            e.printStackTrace();
            LOGGER.warn("send data fail, send to fail topic.");
            kafkaService.sendFailData(requestBean);
            status = "fail";
        }
        return status;
    }

}
