## Kafka producer with schema regitry

### 概述
透過API的方式, 將資料與avro schema結合, 將資料經schema registry驗證後傳送至topic
若schema registry 驗證失敗時, 將傳送到失敗的topic

### 執行環境
* CDP
* Kerberos (LIN.COM)
* schema registry

### CDP 叢集主機
* uh01 : Utility Hosts & kdc server
* wh01, wh02, wh03 : Worker Hosts & kafka broker
* mh01, mh02 : Master Hosts & kafka schema registry


### Kafka Breaker
```
wh01:9092,wh02:9092,wh03:9092
```

### principal (keytab)
```
kadmin.local
xst -norandkey -k <keytab name> <principal name>
```

### jaas.conf
```
參考 config/jaas.conf
```

### client.properties
```
參考 config/client.properties
```

### krb5.conf
```
有安裝kerberos之主機預設位置在 /etc/krb5.conf 
```

### Schema
``` 
參考 src/main/resources/schema/spentRecord.avsc
```

### Topic 建立
```shell
export KAFKA_OPTS="-Djava.security.auth.login.config=/home/user/jaas.conf"
kafka-topics --create --topic spentRecord --partitions 1 --replication-factor 1 --bootstrap-server wh01:9092 --command-config client.properties
kafka-topics --create --topic failSpentRecord --partitions 1 --replication-factor 1 --bootstrap-server wh01:9092 --command-config client.properties
kafka-topics --list --bootstrap-server wh01:9092 --command-config client.properties
```

### 部署位置
```
/etc/krb5.conf
/home/bdpadmin/bdpadmin.keytab
/home/bdpadmin/client.properties
/home/bdpadmin/jaas.conf
/home/bdpadmin/kafka-schema-registry-producer-example-0.0.1-SNAPSHOT.jar
```


### 執行方式
```shell
java -jar kafka-schema-registry-prodcer-example-0.0.1-SNAPSHOT.jar
```

### API 範例
```
Method: POST
URL: http://<url>:8080/api/sendData
Request Body:
{
    "cardType":"VISA",
    "cardNo":"1234432156788765",
    "transType":"消費",
    "dateTime":"2022-01-17 14:20:00",
    "storeNo":"427783",
    "posNo":"123"
}

```